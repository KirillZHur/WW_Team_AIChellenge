package mai.challenge.correspondence.entity

import jakarta.persistence.Entity
import jakarta.persistence.Id
import jakarta.persistence.Table
import java.util.UUID

@Entity
@Table(name = "user_roles")
data class UserRole(
    @Id
    val id: Long? = null,
    val userId: UUID,
    val roleId: Long,
)