package mai.challenge.correspondence.model

enum class Roles {
    PRODUCER,
    CONSUMER,
}