package mai.challenge.correspondence.repository

import mai.challenge.correspondence.entity.UserRole
import org.springframework.data.repository.CrudRepository

interface UserRoleRepository : CrudRepository<UserRole, Long> {
}